#ifndef VECTOR_UTILITIES_H
#define VECTOR_UTILITIES_H

#include <cmath>
#include <iostream>
#include <iomanip>
#include <string>
#include <cassert>

using namespace std;



#endif