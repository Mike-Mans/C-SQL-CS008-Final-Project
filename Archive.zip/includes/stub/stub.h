#ifndef B_STUB_H
#define B_STUB_H
bool stub();      //stub to show how included libraries are incorporated
                  //  into our projects

#endif