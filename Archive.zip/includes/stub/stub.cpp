#include <iostream>
#include <iomanip>
#include "stub.h"

bool stub(){
  return true;
}